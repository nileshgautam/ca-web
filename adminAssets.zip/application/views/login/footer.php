<!-- Bootstrap -->
<script src="<?php echo base_url()?>adminAssets/js/bootstrap.bundle.min.js"></script>
</body>

</html>